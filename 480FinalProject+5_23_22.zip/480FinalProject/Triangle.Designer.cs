﻿
namespace _480FinalProject
{
    partial class Triangle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.sideTextBox1 = new System.Windows.Forms.TextBox();
            this.sideTextBox2 = new System.Windows.Forms.TextBox();
            this.submitBtn = new System.Windows.Forms.Button();
            this.sideTextBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.outputBox = new System.Windows.Forms.TextBox();
            this.ShapesBtn = new System.Windows.Forms.Button();
            this.HomeBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Side 1:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Side 2:";
            // 
            // sideTextBox1
            // 
            this.sideTextBox1.Location = new System.Drawing.Point(12, 41);
            this.sideTextBox1.Name = "sideTextBox1";
            this.sideTextBox1.Size = new System.Drawing.Size(150, 31);
            this.sideTextBox1.TabIndex = 2;
            // 
            // sideTextBox2
            // 
            this.sideTextBox2.Location = new System.Drawing.Point(12, 116);
            this.sideTextBox2.Name = "sideTextBox2";
            this.sideTextBox2.Size = new System.Drawing.Size(150, 31);
            this.sideTextBox2.TabIndex = 3;
            // 
            // submitBtn
            // 
            this.submitBtn.Location = new System.Drawing.Point(12, 245);
            this.submitBtn.Name = "submitBtn";
            this.submitBtn.Size = new System.Drawing.Size(112, 34);
            this.submitBtn.TabIndex = 4;
            this.submitBtn.Text = "Submit";
            this.submitBtn.UseVisualStyleBackColor = true;
            this.submitBtn.Click += new System.EventHandler(this.submitBtn_Click);
            // 
            // sideTextBox3
            // 
            this.sideTextBox3.Location = new System.Drawing.Point(13, 189);
            this.sideTextBox3.Name = "sideTextBox3";
            this.sideTextBox3.Size = new System.Drawing.Size(150, 31);
            this.sideTextBox3.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Side 3:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(338, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Output:";
            // 
            // outputBox
            // 
            this.outputBox.Location = new System.Drawing.Point(338, 42);
            this.outputBox.Multiline = true;
            this.outputBox.Name = "outputBox";
            this.outputBox.ReadOnly = true;
            this.outputBox.Size = new System.Drawing.Size(227, 74);
            this.outputBox.TabIndex = 8;
            // 
            // ShapesBtn
            // 
            this.ShapesBtn.Location = new System.Drawing.Point(148, 314);
            this.ShapesBtn.Name = "ShapesBtn";
            this.ShapesBtn.Size = new System.Drawing.Size(112, 34);
            this.ShapesBtn.TabIndex = 14;
            this.ShapesBtn.Text = "Shapes";
            this.ShapesBtn.UseVisualStyleBackColor = true;
            this.ShapesBtn.Click += new System.EventHandler(this.ShapesBtn_Click);
            // 
            // HomeBtn
            // 
            this.HomeBtn.Location = new System.Drawing.Point(12, 314);
            this.HomeBtn.Name = "HomeBtn";
            this.HomeBtn.Size = new System.Drawing.Size(112, 34);
            this.HomeBtn.TabIndex = 13;
            this.HomeBtn.Text = "Home";
            this.HomeBtn.UseVisualStyleBackColor = true;
            this.HomeBtn.Click += new System.EventHandler(this.HomeBtn_Click);
            // 
            // Triangle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ShapesBtn);
            this.Controls.Add(this.HomeBtn);
            this.Controls.Add(this.outputBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.sideTextBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.submitBtn);
            this.Controls.Add(this.sideTextBox2);
            this.Controls.Add(this.sideTextBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Triangle";
            this.Text = "Triangle";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox sideTextBox1;
        private System.Windows.Forms.TextBox sideTextBox2;
        private System.Windows.Forms.Button submitBtn;
        private System.Windows.Forms.TextBox sideTextBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox outputBox;
        private System.Windows.Forms.Button ShapesBtn;
        private System.Windows.Forms.Button HomeBtn;
    }
}