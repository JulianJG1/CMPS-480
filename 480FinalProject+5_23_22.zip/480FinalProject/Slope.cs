﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _480FinalProject
{
    public partial class Slope : Form
    {
        //Declare values
        Double X1, X2, Y1, Y2, Numerator, Denominator, SlopeValue;
        //Returns to the home page when clcked on 
        private void HomeBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home HomePage = new Home();
            HomePage.ShowDialog();
            this.Close();
        }

        public Slope()
        {
            InitializeComponent();
        }
        //Submit values to be computed and includes error handling.
        private void button1_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(Input1.Text, out X1) || !double.TryParse(Input2.Text, out X1) || !double.TryParse(Input3.Text, out X1) || !double.TryParse(Input4.Text, out X1))
            {
                MessageBox.Show("This is a number only field");
            }
            else
            {
                setVariables();
                Numerator = Y2 - Y1;
                Math.Round(Numerator, 2);
                Denominator = X2 - X1;
                Math.Round(Denominator, 2);
                SlopeValue = Denominator / Numerator;
                Math.Round(SlopeValue, 2);
                label1.Text = "Slope: " + SlopeValue.ToString();
                label6.Text = " Rise: " + Numerator + " Run: " + Denominator;
            }
        }
        //this method sets the variables when called
        public void setVariables()
        {
            X1 = Convert.ToDouble(Input4.Text);
            X2 = Convert.ToDouble(Input3.Text);
            Y1 = Convert.ToDouble(Input2.Text);
            Y2 = Convert.ToDouble(Input1.Text);
        }
    }
}
