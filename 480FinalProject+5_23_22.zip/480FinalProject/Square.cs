﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _480FinalProject
{
    public partial class Square : Form
    {
        public Square()
        {
            InitializeComponent();
        }
        //computes the area and perimeter when the submit button is clicked on 
        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            //create a new instance of a square
            AreaPerimeter.square Square = new AreaPerimeter.square();
            //call methods to compute area and perimeter
            Square.setSide(Convert.ToDouble(textBox1.Text.Trim()));
            Square.findPerimeter();
            Square.findArea();
            //display output
            outputBox.Text = "Area: " + String.Format("{0:0.##}", Square.area) + Environment.NewLine + "Perimeter: " + String.Format("{0:0.##}", Square.perimeter);
        }
        //Returns to the home page when clcked on 
        private void HomeBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home HomePage = new Home();
            HomePage.ShowDialog();
            this.Close();
        }
        //Returns to the shapes page when clcked on 
        private void ShapesBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AreaPerimeter ShapesPage = new AreaPerimeter();
            ShapesPage.ShowDialog();
            this.Close();
        }

    }
}
