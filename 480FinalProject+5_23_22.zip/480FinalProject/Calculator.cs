﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _480FinalProject
{
    public partial class Calculator : Form
    {
        //Initialize values
        Double resultValue = 0;
        String operation = "";
        bool operationTF = false;
        public Calculator()
        {
            InitializeComponent();
        }
        //Enter a value when a number button is clicked on 
        private void button_click(object sender, EventArgs e)
        {
            if ((textBoxResults.Text == "0") || (operationTF))
            {
                textBoxResults.Clear();
            }
            operationTF = false;
            Button button = (Button)sender;
            if (button.Text == ".")
            {
                if (!textBoxResults.Text.Contains("."))
                {
                    textBoxResults.Text = textBoxResults.Text + button.Text;
                }
            }
            else
            textBoxResults.Text = button.Text;
        }
        //occurs when operator is clicked on 
        private void operator_click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            if (resultValue != 0)
            {
                buttonEqual.PerformClick();
                operation = button.Text;
                resultValue = Double.Parse(textBoxResults.Text);
                operationTF = true;
            }
            else
            {
                operation = button.Text;
                resultValue = Double.Parse(textBoxResults.Text);
                currentInput.Text = resultValue + " " + operation;
                operationTF = true;
            }
        }
        //clears value that was enter when C is clicked on 
        private void clear_click(object sender, EventArgs e)
        {
            textBoxResults.Text = "0";
        }
        //clears entry when CE is clicked on 
        private void clearEntry_click(object sender, EventArgs e)
        {
            textBoxResults.Text = "0";
            resultValue = 0;
        }
        //shows results when clcked on 
        private void result_click(object sender, EventArgs e)
        {
            switch (operation)
            {
                case "+":
                    textBoxResults.Text = (resultValue + Double.Parse(textBoxResults.Text)).ToString();
                    break;

                case "-":
                    textBoxResults.Text = (resultValue - Double.Parse(textBoxResults.Text)).ToString();
                    break;

                case "*":
                    textBoxResults.Text = (resultValue * Double.Parse(textBoxResults.Text)).ToString();
                    break;

                case "/":
                    textBoxResults.Text = (resultValue / Double.Parse(textBoxResults.Text)).ToString();
                    break;
            }
            resultValue = Double.Parse(textBoxResults.Text);
            currentInput.Text = "";
        }
        //Returns to the home page when clcked on 
        private void HomeBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home HomePage = new Home();
            HomePage.ShowDialog();
            this.Close();
        }
    }
}
