﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _480FinalProject
{
    public partial class Circle : Form
    {
        public Circle()
        {
            InitializeComponent();
        }
        //computes the area and perimeter when the submit button is clicked on 
        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            //create a new instance of a circle
            AreaPerimeter.circle Circle = new AreaPerimeter.circle();
            //call methods to compute area and perimeter
            Circle.setRadius(Convert.ToDouble(textBox1.Text.Trim()));
            Circle.findPerimeter();
            Circle.findArea();
            //output results
            outputBox.Text = "Area: " + String.Format("{0:0.##}", Circle.area) + Environment.NewLine + "Perimeter: " + String.Format("{0:0.##}", Circle.perimeter);
        }
        //Returns to the home page when clcked on 
        private void HomeBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home HomePage = new Home();
            HomePage.ShowDialog();
            this.Close();
        }
        //Returns to the shapes page when clcked on 
        private void ShapesBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AreaPerimeter ShapesPage = new AreaPerimeter();
            ShapesPage.ShowDialog();
            this.Close();
        }

    }
}
