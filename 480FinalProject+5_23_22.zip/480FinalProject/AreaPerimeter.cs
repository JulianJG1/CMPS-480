﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _480FinalProject
{
    public partial class AreaPerimeter : Form
    {
        public AreaPerimeter()
        {
            InitializeComponent();
        }
        //Sends user to square page when button is checked on  
        private void squareBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Square squarePage = new Square();
            squarePage.ShowDialog();
            this.Close();
        }
        //Sends user to cricle page when button is checked on  
        private void CircleBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Circle circlePage = new Circle();
            circlePage.ShowDialog();
            this.Close();
        }
        //Sends user to triangle page when button is checked on  
        private void TriangleBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Triangle trianlglePage = new Triangle();
            trianlglePage.ShowDialog();
            this.Close();
        }
        //Sends user to rectangle page when button is checked on  
        private void RectangleBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Rectangle rectanglePage = new Rectangle();
            rectanglePage.ShowDialog();
            this.Close();
        }

        public class shapes//class for shapes. base class
        {
            protected double width;
            protected double length;
            public double perimeter;
            public double area;
            public virtual void setLengthAndWidth(double aLength, double aWidth)//function to set the length and width.
            {
                length = aLength;
                width = aWidth;
            }
            public virtual void findPerimeter()//functions finds the perimeter 
            {
                perimeter = 2 * (width + length);
            }
            public virtual void findArea()//functions finds the area 
            {
                area = width * length;
            }

        }

        public class square : shapes//class for square. Derived class
        {
            private double side;

            public void setSide(double aSide)//function to set the sides of a square.
            {
                side = aSide;
            }

            public override void findPerimeter()//functions finds the perimeter of a square
            {
                perimeter = 4 * (side);
            }

            public override void findArea()//functions finds the area of a square
            {
                area = side * side;
            }
        }

        public class rectangle : shapes//class for rectangle. Derived class
        {
            public rectangle() { }//constructor 
        }


        public class triangle : shapes//class for triangle. Derived class
        {
            private double side1;
            private double side2;
            private double side3;
            private double semiperimeter;

            public void set3Sides(double aSide1, double aSide2, double aSide3)//function to set the sides of a triangle
            {
                side1 = aSide1;
                side2 = aSide2;
                side3 = aSide3;
            }

            public override void findPerimeter()//functions finds the perimeter and semiperimeter of a triangle
            {
                perimeter = side1 + side2 + side3;
                semiperimeter = perimeter / 2;
            }

            public override void findArea()//functions finds the area of a triangle
            {
                area = Math.Sqrt(semiperimeter * (semiperimeter - side1) * (semiperimeter - side2) * (semiperimeter - side3));
            }
        }


        public class circle : shapes//class for circle. Derived class
        {
            private double radius;
            private const double PI = 3.1415926535897931;
            public void setRadius(double aRadius)//function to set the radius of a circle.
            {
                radius = aRadius;
            }

            public override void findPerimeter()//functions finds the perimeter of a circle
            {
                perimeter = 2 * PI * radius;
            }

            public override void findArea()//functions finds the area of a circle
            {
                area = PI * (radius * radius);
            }
        }
        //Returns to the home page when clcked on 
        private void HomeBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home HomePage = new Home();
            HomePage.ShowDialog();
            this.Close();
        }
    }
}
