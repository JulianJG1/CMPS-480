﻿using RestSharp;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _480FinalProject
{
    public partial class Random : Form
    {
        public Random()
        {
            InitializeComponent();
        }

        //When button is clicked, generate new integer using API
        private void generateBtn_Click(object sender, EventArgs e)
        {
            var client = new RestClient("https://www.random.org/integers/?num=1&min=0&max=100&col=1&base=10&format=plain&rnd=new");
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AlwaysMultipartFormData = true;
            IRestResponse response = client.Execute(request);
            int test = Convert.ToInt32(response.Content);
            ResultsTextBox.Text = Convert.ToString(test);
        }
        //Returns to the home page when clcked on 
        private void HomeBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home HomePage = new Home();
            HomePage.ShowDialog();
            this.Close();
        }
    }
}
