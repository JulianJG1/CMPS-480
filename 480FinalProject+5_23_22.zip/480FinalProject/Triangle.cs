﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _480FinalProject
{
    public partial class Triangle : Form
    {
        public Triangle()
        {
            InitializeComponent();
        }
        //computes the area and perimeter when the submit button is clicked on 
        private void submitBtn_Click(object sender, EventArgs e)
        {
            //create a new instance of triangle
            AreaPerimeter.triangle triangle = new AreaPerimeter.triangle();
            //call methods to compute area and perimeter
            triangle.set3Sides(Convert.ToDouble(sideTextBox1.Text.Trim()), Convert.ToDouble(sideTextBox2.Text.Trim()), Convert.ToDouble(sideTextBox3.Text.Trim()));
            triangle.findPerimeter();
            triangle.findArea();
            //output results
            outputBox.Text = "Area: " + String.Format("{0:0.##}", triangle.area) + Environment.NewLine + "Perimeter: " + String.Format("{0:0.##}", triangle.perimeter);
        }
        //Returns to the home page when clcked on 
        private void HomeBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home HomePage = new Home();
            HomePage.ShowDialog();
            this.Close();
        }
        //Returns to the shapes page when clcked on 
        private void ShapesBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AreaPerimeter ShapesPage = new AreaPerimeter();
            ShapesPage.ShowDialog();
            this.Close();
        }
    }
}
