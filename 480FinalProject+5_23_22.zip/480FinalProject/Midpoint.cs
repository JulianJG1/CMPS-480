﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _480FinalProject
{
    public partial class Midpoint : Form
    {
        public Midpoint()
        {
            InitializeComponent();
        }
        //calls methods from MidpointClass to compute values and displays values in outputBox
        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            MidpointClass midpoint = new MidpointClass();

            double xAverage = midpoint.MidPointComputeY(Convert.ToDouble(textBox1.Text.Trim()), Convert.ToDouble(textBox2.Text.Trim()));
            double yAverage = midpoint.MidPointComputeY(Convert.ToDouble(textBox3.Text.Trim()), Convert.ToDouble(textBox4.Text.Trim()));
            //output results
            outputBox.Text = "Midpoint: (" + String.Format("{0:0.##}", xAverage) + ", " + String.Format("{0:0.##}", yAverage) + ")";
        }
        //Returns to the home page when clcked on 
        private void HomeBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home HomePage = new Home();
            HomePage.ShowDialog();
            this.Close();
        }
    }
    //Midpint class includes method to compute x and y averages
    public class MidpointClass 
    {
        public double MidPointComputeX(double x1, double x2)
        {
            double xAverage;

            xAverage = (x1 + x2) / 2;

            return xAverage;

        }

        public double MidPointComputeY(double y1, double y2)
        {
            double yAverage;

            yAverage = (y1 + y2) / 2;

            return yAverage;

        }
    }
}
