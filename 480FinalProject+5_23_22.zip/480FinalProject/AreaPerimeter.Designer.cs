﻿
namespace _480FinalProject
{
    partial class AreaPerimeter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.squareBtn = new System.Windows.Forms.Button();
            this.CircleBtn = new System.Windows.Forms.Button();
            this.TriangleBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.RectangleBtn = new System.Windows.Forms.Button();
            this.HomeBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // squareBtn
            // 
            this.squareBtn.Location = new System.Drawing.Point(12, 154);
            this.squareBtn.Name = "squareBtn";
            this.squareBtn.Size = new System.Drawing.Size(112, 34);
            this.squareBtn.TabIndex = 0;
            this.squareBtn.Text = "Square";
            this.squareBtn.UseVisualStyleBackColor = true;
            this.squareBtn.Click += new System.EventHandler(this.squareBtn_Click);
            // 
            // CircleBtn
            // 
            this.CircleBtn.BackColor = System.Drawing.SystemColors.Control;
            this.CircleBtn.Location = new System.Drawing.Point(12, 48);
            this.CircleBtn.Name = "CircleBtn";
            this.CircleBtn.Size = new System.Drawing.Size(112, 34);
            this.CircleBtn.TabIndex = 1;
            this.CircleBtn.Text = "Circle";
            this.CircleBtn.UseVisualStyleBackColor = false;
            this.CircleBtn.Click += new System.EventHandler(this.CircleBtn_Click);
            // 
            // TriangleBtn
            // 
            this.TriangleBtn.Location = new System.Drawing.Point(12, 204);
            this.TriangleBtn.Name = "TriangleBtn";
            this.TriangleBtn.Size = new System.Drawing.Size(112, 34);
            this.TriangleBtn.TabIndex = 2;
            this.TriangleBtn.Text = "Triangle";
            this.TriangleBtn.UseVisualStyleBackColor = true;
            this.TriangleBtn.Click += new System.EventHandler(this.TriangleBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Choose a Shape:";
            // 
            // RectangleBtn
            // 
            this.RectangleBtn.Location = new System.Drawing.Point(12, 100);
            this.RectangleBtn.Name = "RectangleBtn";
            this.RectangleBtn.Size = new System.Drawing.Size(112, 34);
            this.RectangleBtn.TabIndex = 4;
            this.RectangleBtn.Text = "Rectangle";
            this.RectangleBtn.UseVisualStyleBackColor = true;
            this.RectangleBtn.Click += new System.EventHandler(this.RectangleBtn_Click);
            // 
            // HomeBtn
            // 
            this.HomeBtn.Location = new System.Drawing.Point(12, 255);
            this.HomeBtn.Name = "HomeBtn";
            this.HomeBtn.Size = new System.Drawing.Size(112, 34);
            this.HomeBtn.TabIndex = 28;
            this.HomeBtn.Text = "Home";
            this.HomeBtn.UseVisualStyleBackColor = true;
            this.HomeBtn.Click += new System.EventHandler(this.HomeBtn_Click);
            // 
            // AreaPerimeter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.HomeBtn);
            this.Controls.Add(this.RectangleBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TriangleBtn);
            this.Controls.Add(this.CircleBtn);
            this.Controls.Add(this.squareBtn);
            this.Name = "AreaPerimeter";
            this.Text = "Area and Perimeter of Shapes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button squareBtn;
        private System.Windows.Forms.Button CircleBtn;
        private System.Windows.Forms.Button TriangleBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button RectangleBtn;
        private System.Windows.Forms.Button HomeBtn;
    }
}