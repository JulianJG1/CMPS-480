﻿
namespace _480FinalProject
{
    partial class Home
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.DefaultCalBtn = new System.Windows.Forms.Button();
            this.SlopeBtn = new System.Windows.Forms.Button();
            this.AreaPerimeterBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.MidpointBtn = new System.Windows.Forms.Button();
            this.RandomBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select an Option:";
            // 
            // DefaultCalBtn
            // 
            this.DefaultCalBtn.Location = new System.Drawing.Point(12, 101);
            this.DefaultCalBtn.Name = "DefaultCalBtn";
            this.DefaultCalBtn.Size = new System.Drawing.Size(179, 34);
            this.DefaultCalBtn.TabIndex = 1;
            this.DefaultCalBtn.Text = "Default Calculator";
            this.DefaultCalBtn.UseVisualStyleBackColor = true;
            this.DefaultCalBtn.Click += new System.EventHandler(this.DefaultCalBtn_Click);
            // 
            // SlopeBtn
            // 
            this.SlopeBtn.Location = new System.Drawing.Point(12, 152);
            this.SlopeBtn.Name = "SlopeBtn";
            this.SlopeBtn.Size = new System.Drawing.Size(179, 34);
            this.SlopeBtn.TabIndex = 2;
            this.SlopeBtn.Text = "Find the Slope";
            this.SlopeBtn.UseVisualStyleBackColor = true;
            this.SlopeBtn.Click += new System.EventHandler(this.SlopeBtn_Click);
            // 
            // AreaPerimeterBtn
            // 
            this.AreaPerimeterBtn.Location = new System.Drawing.Point(12, 205);
            this.AreaPerimeterBtn.Name = "AreaPerimeterBtn";
            this.AreaPerimeterBtn.Size = new System.Drawing.Size(179, 34);
            this.AreaPerimeterBtn.TabIndex = 3;
            this.AreaPerimeterBtn.Text = "Area and Perimeter";
            this.AreaPerimeterBtn.UseVisualStyleBackColor = true;
            this.AreaPerimeterBtn.Click += new System.EventHandler(this.AreaPerimeterBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(170, 32);
            this.label2.TabIndex = 4;
            this.label2.Text = "Calculator App";
            // 
            // MidpointBtn
            // 
            this.MidpointBtn.Location = new System.Drawing.Point(12, 259);
            this.MidpointBtn.Name = "MidpointBtn";
            this.MidpointBtn.Size = new System.Drawing.Size(179, 34);
            this.MidpointBtn.TabIndex = 5;
            this.MidpointBtn.Text = "Midpoint";
            this.MidpointBtn.UseVisualStyleBackColor = true;
            this.MidpointBtn.Click += new System.EventHandler(this.MidpointBtn_Click);
            // 
            // RandomBtn
            // 
            this.RandomBtn.Location = new System.Drawing.Point(12, 316);
            this.RandomBtn.Name = "RandomBtn";
            this.RandomBtn.Size = new System.Drawing.Size(179, 34);
            this.RandomBtn.TabIndex = 6;
            this.RandomBtn.Text = "Random Integer";
            this.RandomBtn.UseVisualStyleBackColor = true;
            this.RandomBtn.Click += new System.EventHandler(this.RandomBtn_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.RandomBtn);
            this.Controls.Add(this.MidpointBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.AreaPerimeterBtn);
            this.Controls.Add(this.SlopeBtn);
            this.Controls.Add(this.DefaultCalBtn);
            this.Controls.Add(this.label1);
            this.Name = "Home";
            this.Text = "Home";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button DefaultCalBtn;
        private System.Windows.Forms.Button SlopeBtn;
        private System.Windows.Forms.Button AreaPerimeterBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button MidpointBtn;
        private System.Windows.Forms.Button RandomBtn;
    }
}

