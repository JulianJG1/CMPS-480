﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _480FinalProject
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }
        //Opens calculator page when clicked on 
        private void DefaultCalBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Calculator calculatorPage = new Calculator();
            calculatorPage.ShowDialog();
            this.Close();
        }
        //Opens slope page when clicked on 
        private void SlopeBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Slope slopePage = new Slope();
            slopePage.ShowDialog();
            this.Close();
        }
        //Opens area and perimeter page when clicked on
        private void AreaPerimeterBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AreaPerimeter areaPerimeterPage = new AreaPerimeter();
            areaPerimeterPage.ShowDialog();
            this.Close();
        }
        //Opens midpint page when clicked on 
        private void MidpointBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Midpoint MidpointPage = new Midpoint();
            MidpointPage.ShowDialog();
            this.Close();
        }
        //Opens random integer page when clicked on 
        private void RandomBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Random RandomPage = new Random();
            RandomPage.ShowDialog();
            this.Close();
        }
    }
}
