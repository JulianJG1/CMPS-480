﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course
{
    public partial class Form1 : Form
    {
        List<string> course = new List<string>();
        string courselist = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for(int i = 0; i<course.Count; i++)
            {
                if((course.Count-1) == i)
                {
                    OutputTxt.Text += course[i];
                }
                else
                {
                    OutputTxt.Text += course[i] + ", ";
                }
            }
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            string courseentry = newCourseTxt.Text.Trim();
            string courseentry2 = textBox1.Text.Trim();
            string courseentry3 = textBox2.Text.Trim();
            string courseentry4 = textBox3.Text.Trim();
            string courseentry5 = textBox4.Text.Trim();
            bool outthere = false;

            for (int i = 0; i < course.Count; i++)
            {
                if (courseentry == course[i])
                {
                    MessageBox.Show("The course that you have just entered is already in existence!");
                    outthere = true;
                    break;
                }
            }
            if (outthere == true)
            {
                outthere = false;
            }
            else
            {
                if (courseentry.Contains("-"))
                {
                    courseentry = courseentry.Replace("-", " ");
                    courseentry2 = courseentry2.Replace("-", " ");
                    courseentry3 = courseentry3.Replace("-", " ");
                    courseentry4 = courseentry4.Replace("-", " ");
                    courseentry5 = courseentry5.Replace("-", " ");
                }
                course.Add(courseentry.Trim());
                course.Add(courseentry2.Trim());
                course.Add(courseentry3.Trim());
                course.Add(courseentry4.Trim());
                course.Add(courseentry5.Trim());
                MessageBox.Show("The course has been succesfully added");
                OutputTxt.Text = "";
                for (int i = 0; i < course.Count; i++)
                {
                    if ((course.Count - 1) == i)
                    {
                        OutputTxt.Text += course[i];
                    }
                    else
                    {
                        OutputTxt.Text += course[i] + ", ";
                    }
                }
                newCourseTxt.Text = "";
            }
        }
    }
}
